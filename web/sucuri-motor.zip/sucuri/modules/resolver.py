"""Resolver a equação — e dizer que tipo de resposta é.

O `dsolve` responde "consigo achar uma solução?", nunca "existe uma?". Não
achar não prova nada, e é o próprio SymPy quem esconde isso: ele rebaixa a
resposta sem avisar. Medido na versão que o Sucuri fixa:

    y'' + y = 0          C1·sin(x) + C2·cos(x)          forma fechada
    y'' = x y            C1·airyai(x) + C2·airybi(x)    forma fechada
    y'' + x y' + y = 0   ... + O(x**6)                  SÉRIE TRUNCADA
    y'' = 6 y^2          (não termina)
    y' = y^2 + x         TypeError dentro do solver

A terceira é a perigosa: a equação tem forma fechada (ela é (y' + xy)' = 0, e o
próprio SymPy resolve isso com erfi), mas o que volta é uma série até ordem 5.
Quem não olhar o `O(x**6)` no fim não percebe que mudou de tipo de resposta.

Por isso este módulo faz três coisas que o `dsolve` sozinho não faz:

1. **classifica a resposta** — forma fechada, série truncada, relação
   implícita ou nada;
2. **confere por substituição**, com `checkodesol`: solução que não volta zero
   na equação não se apresenta como conclusão, por mais bonita que seja;
3. **põe prazo**. O `dsolve` não tem como ser interrompido de fora, e em
   y'' = 6y² ele não volta.

E quando não acha, diz a única coisa honesta: não achar não é prova de que não
existe. Quem responde a essa outra pergunta é o módulo `korvin`.
"""

from __future__ import annotations

import sympy as sp
from sympy.core.function import AppliedUndef

from ..prazo import SEM_PROCESSOS, TempoEsgotado, desempacotar, empacotar, no_prazo
from . import Module, Operation, Provenance, Result, register

# Reexportados: os testes do módulo apontam para eles, e o prazo é parte do
# contrato desta operação, não um detalhe interno.
_no_prazo, _empacotar, _desempacotar = no_prazo, empacotar, desempacotar

PRAZO_RESOLVER = 20
PRAZO_CONFERIR = 10


# ------------------------------------------------------------- a equação

def edo(expression):
    """(equação, função incógnita, variável) — ou uma recusa explicada.

    Deliberadamente estreito, como o adaptador do KORVIN: o módulo diz o que
    aceita em vez de adivinhar a intenção.
    """
    expr = expression.to_sympy()
    if isinstance(expr, sp.Equality):
        equacao = expr
    else:
        equacao = sp.Eq(expr, 0)

    derivadas = equacao.atoms(sp.Derivative)
    if not derivadas:
        raise ValueError("não há derivada nenhuma: isto não é equação diferencial")

    incognitas = {a.func for d in derivadas for a in d.atoms(AppliedUndef)}
    if not incognitas:
        raise ValueError(
            "a derivada não é de uma função incógnita. Declare a função — em "
            "y'' + y = 0, é preciso dizer que y é função de x")
    if len(incognitas) > 1:
        nomes = ", ".join(sorted(f.__name__ for f in incognitas))
        raise ValueError(
            f"há mais de uma função incógnita ({nomes}): isto é um sistema, e "
            f"este módulo resolve uma equação de cada vez")

    variaveis = sorted({v for d in derivadas for v in d.variables}, key=str)
    funcao = next(iter(incognitas))

    # Uma variável ou várias: a diferença não é de recusa, é de SOLVER. A
    # incógnita de várias variáveis vai para o pdsolve, que resolve bem menos
    # do que o dsolve mas resolve — ∂u/∂t = A(t)u sai como F(x)·exp(∫A dt), com
    # a "constante" de integração sendo uma função arbitrária de x, que é o que
    # ela é numa EDP.
    args = self_args(equacao, funcao)
    return equacao, funcao(*args), variaveis[0]


def self_args(equacao, funcao):
    """Os argumentos com que a função incógnita aparece na equação."""
    for a in equacao.atoms(AppliedUndef):
        if a.func is funcao:
            return a.args
    return ()


def _ordem(equacao, funcao):
    return sp.ode_order(equacao, funcao.func)


# ----------------------------------------------------- tipo de resposta

FECHADA = "forma fechada"
SERIE = "série truncada"
IMPLICITA = "relação implícita"
NENHUMA = "nenhuma"


def tipo_da_resposta(solucao, funcao):
    """Que espécie de objeto o solver devolveu.

    A distinção que o `dsolve` não faz: uma série truncada não é uma solução,
    é uma aproximação até certa ordem, e tratá-la como solução é o erro que
    este módulo existe para impedir.
    """
    if solucao is None:
        return NENHUMA, None
    if isinstance(solucao, (list, tuple)):
        tipos = [tipo_da_resposta(s, funcao)[0] for s in solucao]
        return (SERIE if SERIE in tipos else tipos[0]), None

    ordem = solucao.rhs.getO() if hasattr(solucao.rhs, "getO") else None
    if ordem is not None or solucao.has(sp.Order):
        return SERIE, ordem
    if solucao.lhs != funcao:
        return IMPLICITA, None
    return FECHADA, None


# --------------------------------------------------------------- operações

def parcial(funcao):
    """A incógnita tem mais de um argumento? Então é EDP, e o solver é outro."""
    return len(funcao.args) > 1


def _dsolve(equacao, funcao):
    return (sp.pdsolve(equacao, funcao) if parcial(funcao)
            else sp.dsolve(equacao, funcao))


def _checkodesol(equacao, solucao, ehparcial=False):
    return (sp.checkpdesol(equacao, solucao) if ehparcial
            else sp.checkodesol(equacao, solucao))


def _classificar(equacao, funcao):
    return (sp.classify_pde(equacao, funcao) if parcial(funcao)
            else sp.classify_ode(equacao, funcao))


def _confere(equacao, solucao, ehparcial=False):
    """A solução volta zero quando substituída? ('sim'/'não'/'não deu tempo')"""
    try:
        veredito = no_prazo(_checkodesol, PRAZO_CONFERIR, equacao, solucao,
                            ehparcial)
    except TempoEsgotado:
        return None, f"não deu tempo de conferir em {PRAZO_CONFERIR} s"
    except Exception as e:                                      # noqa: BLE001
        return None, f"a conferência falhou: {e}"

    if isinstance(veredito, list):
        oks = [v[0] for v in veredito]
        restos = [v[1] for v in veredito]
        if all(oks):
            return True, f"{len(oks)} soluções substituídas: resto 0 em todas"
        return False, f"resto não nulo em {oks.count(False)} de {len(oks)}: {restos}"

    ok, resto = veredito
    if ok:
        return True, "substituída na equação: resto 0"
    return False, f"substituída na equação: resto {sp.sstr(resto)[:60]}"


_NAO_E_PROVA = ("não achar solução não é prova de que não existe; para essa "
                "outra pergunta, o módulo korvin")


def _sem_solucao(linhas, motivo, equacao=None, funcao=None):
    """O desfecho mais comum, e o que mais precisa de rótulo honesto.

    Rotular isto de "solução" seria a mentira do próprio `dsolve`: o que houve
    foi o solver não achar, e não achar não é achar que não há.

    É aqui que os padrões tentados valem alguma coisa. Quando a conta fecha,
    saber que o caminho foi '2nd_linear_airy' é curiosidade; quando não fecha,
    é o começo do diagnóstico — lista vazia, ou só com 'power_series' e
    'lie_group', já dizia que não ia vir forma fechada. Por isso vêm junto com
    o fracasso, e não numa operação à parte que o usuário teria de saber pedir.
    """
    if equacao is not None:
        try:
            padroes = no_prazo(_classificar, PRAZO_CONFERIR, equacao, funcao)
        except Exception:                                       # noqa: BLE001
            padroes = ()
        linhas = linhas + [("padrão tentado", p) for p in padroes]
        if not padroes:
            linhas.append(("padrão tentado",
                           "nenhum: o SymPy não tem por onde começar"))

    return Result("sem solução encontrada", None,
                  rows=linhas + [("tipo", NENHUMA), ("motivo", motivo)],
                  provenance=Provenance.INAPPLICABLE,
                  blocked_by=[_NAO_E_PROVA])


def resolver(expression):
    """Resolve, classifica a resposta e confere por substituição."""
    equacao, funcao, _ = edo(expression)
    ordem = _ordem(equacao, funcao)
    linhas = [("equação", sp.sstr(equacao)), ("ordem", str(ordem)),
              ("espécie", "parcial" if parcial(funcao) else "ordinária")]

    try:
        solucao = no_prazo(_dsolve, PRAZO_RESOLVER, equacao, funcao)
    except TempoEsgotado as e:
        return _sem_solucao(linhas, str(e), equacao, funcao)
    except Exception as e:                                      # noqa: BLE001
        return _sem_solucao(linhas, f"o solver falhou: {e}", equacao, funcao)

    tipo, ordem_serie = tipo_da_resposta(solucao, funcao)
    linhas.append(("tipo", tipo if ordem_serie is None
                   else f"{tipo} em {sp.sstr(ordem_serie)}"))

    if tipo == SERIE:
        # Série truncada não é solução: é aproximação até uma ordem. Vai como
        # DADO, nunca como conclusão, e o rótulo diz isso.
        linhas.append(("solução", sp.sstr(solucao)))
        return Result("série (não é solução fechada)", solucao,
                      latex=sp.latex(solucao), rows=linhas,
                      provenance=Provenance.INAPPLICABLE)

    linhas.append(("solução", sp.sstr(solucao)))
    conferida, nota = _confere(equacao, solucao, parcial(funcao))
    linhas.append(("conferência", nota))

    if conferida:
        return Result("solução", solucao, latex=sp.latex(solucao), rows=linhas,
                      produz=[solucao], provenance=Provenance.ESTABLISHED)

    # O solver devolveu algo que a substituição não confirmou. É o caso em que
    # a resposta parece perfeita e não se sustenta — não se apresenta.
    return Result("solução não confirmada", solucao, latex=sp.latex(solucao),
                  rows=linhas, provenance=Provenance.UNSOURCED,
                  blocked_by=["a substituição não devolveu zero; o que o solver "
                              "achou não foi verificado"])


def classificar(expression):
    """Os padrões que o SymPy tentaria — a máquina por dentro.

    `classify_ode` devolve uma lista de PADRÕES, não um procedimento de
    decisão. Ver a lista vazia, ou só com 'power_series' e 'lie_group', já
    antecipa que não vem forma fechada.
    """
    equacao, funcao, _ = edo(expression)
    try:
        padroes = no_prazo(_classificar, PRAZO_CONFERIR, equacao, funcao)
    except TempoEsgotado as e:
        padroes = ()
        nota = str(e)
    else:
        nota = None

    linhas = [("ordem", str(_ordem(equacao, funcao)))]
    linhas += [("padrão", p) for p in padroes]
    if not padroes:
        linhas.append(("padrão", nota or "nenhum: o SymPy não tem por onde começar"))

    return Result("padrões aplicáveis", list(padroes), rows=linhas,
                  provenance=Provenance.INAPPLICABLE)


# ------------------------------------------------- separação de variáveis

def separar(expression):
    """Reduz uma EDP a equações ordinárias sob o ansatz u = T(t)·X(x).

    É o caminho clássico para a equação da onda, e o SymPy o percorre —
    `pde_separate_mul` faz a separação, `dsolve` resolve cada pedaço. O
    `pdsolve`, que falha, é só um dos caminhos dele.

    O que NÃO se pode dizer é que isso resolve a equação. Separar supõe que a
    solução é um produto, e essa suposição é uma restrição: o que sai são os
    MODOS, e a solução geral é a superposição deles — que a separação não prova
    ser completa. Por isso o resultado vai como dado, e não como conclusão.
    """
    from sympy.solvers.pde import pde_separate_mul

    equacao, funcao, _ = edo(expression)
    if not parcial(funcao):
        raise ValueError("separar é para equação a derivadas parciais; "
                         f"{funcao} depende de uma variável só")

    variaveis = list(funcao.args)
    fatores = [sp.Function(str(v).upper())(v) for v in variaveis]
    partes = no_prazo(pde_separate_mul, PRAZO_CONFERIR,
                      equacao, funcao, fatores)
    if not partes:
        return Result("não separou", None,
                      rows=[("equação", sp.sstr(equacao)),
                            ("ansatz", " · ".join(sp.sstr(f) for f in fatores))],
                      provenance=Provenance.INAPPLICABLE,
                      blocked_by=["o produto não separa esta equação; separar "
                                  "não é um método geral"])

    k = sp.Symbol("k")
    linhas = [("ansatz", sp.sstr(funcao) + " = "
               + " · ".join(sp.sstr(f) for f in fatores)),
              ("constante", "k")]
    produzidas = []
    for fator, parte in zip(fatores, partes):
        # A equação ordinária de verdade, e não a fração igualada a k: é ela
        # que o dsolve resolve e que o usuário vai querer nomear.
        ordinaria = sp.Eq(sp.together(parte * fator), k * fator)
        produzidas.append(ordinaria)
        linhas.append((f"equação em {fator.args[0]}", sp.sstr(ordinaria)))
        try:
            linhas.append((f"solução em {fator.args[0]}",
                           sp.sstr(no_prazo(sp.dsolve, PRAZO_CONFERIR,
                                            ordinaria, fator))))
        except Exception as e:                                  # noqa: BLE001
            linhas.append((f"solução em {fator.args[0]}", f"não saiu: {e}"))

    return Result("separação de variáveis", partes, rows=linhas,
                  produz=produzidas,
                  provenance=Provenance.INAPPLICABLE,
                  blocked_by=["isto não resolve a equação: separar SUPÕE que a "
                              "solução é um produto. O que sai são os modos, e "
                              "a solução geral é a superposição deles — que a "
                              "separação não prova ser completa"])


def conferir(expression, candidata):
    """A candidata satisfaz a equação? Substitui e diz.

    O verbo que faltava: o SymPy não resolve a equação da onda, mas CONFERE a
    solução de d'Alembert, e conferir é meia matemática — a que separa uma
    resposta de um palpite.
    """
    equacao, funcao, _ = edo(expression)
    solucao = candidata.to_sympy()
    if not isinstance(solucao, sp.Equality):
        raise ValueError("a candidata precisa ser uma igualdade, "
                         "como u = F(x - c t) + G(x + c t)")

    ok, nota = _confere(equacao, solucao, parcial(funcao))
    linhas = [("equação", sp.sstr(equacao)),
              ("candidata", sp.sstr(solucao)),
              ("conferência", nota)]
    if ok:
        return Result("candidata verificada", solucao,
                      latex=sp.latex(solucao), rows=linhas,
                      provenance=Provenance.ESTABLISHED)
    return Result("candidata NÃO verificada", solucao,
                  latex=sp.latex(solucao), rows=linhas,
                  provenance=Provenance.UNSOURCED,
                  blocked_by=["a substituição não devolveu zero"])


MODULE = register(Module(
    name="resolver",
    description="resolve a equação diferencial e diz que tipo de resposta é",
    operations=[
        Operation("resolver",
                  "dsolve com prazo, classificado e conferido por substituição",
                  resolver),
        Operation("padrões",
                  "os métodos que o SymPy tentaria, antes de tentar",
                  classificar),
        Operation("separar",
                  "reduz uma EDP a ordinárias sob o ansatz de produto",
                  separar),
        Operation("conferir",
                  "a candidata satisfaz a equação? substitui e diz",
                  conferir, accepts="duas expressões"),
    ]))
